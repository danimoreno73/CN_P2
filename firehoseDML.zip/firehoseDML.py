import json
import base64
import datetime

def lambda_handler(event, context):
    output = []
    for record in event['records']:
        try:
            # 1. Decodificar
            payload = base64.b64decode(record['data']).decode('utf-8')
            data_json = json.loads(payload)
            
            # 2. TRANSFORMACIÓN (Requisito Práctica): Filtrado
            # Si el dato no tiene país, lo marcamos como 'Dropped' (se borra)
            if 'country' not in data_json or not data_json['country']:
                output_record = {
                    'recordId': record['recordId'],
                    'result': 'Dropped',
                    'data': record['data']
                }
            else:
                # 3. Enriquecimiento y Formato
                # Añadimos timestamp de procesado
                processing_time = datetime.datetime.now(datetime.timezone.utc)
                data_json['processed_at'] = processing_time.isoformat()
                
                # REQUISITO VITAL: Añadir salto de línea (\n) para que Glue lo lea bien
                payload_transformed = json.dumps(data_json) + '\n'
                
                output_record = {
                    'recordId': record['recordId'],
                    'result': 'Ok',
                    'data': base64.b64encode(payload_transformed.encode('utf-8')).decode('utf-8')
                }
                
            output.append(output_record)

        except Exception as e:
            print(f"Error: {e}")
            output.append({
                'recordId': record['recordId'],
                'result': 'ProcessingFailed',
                'data': record['data']
            })
    
    return {'records': output}